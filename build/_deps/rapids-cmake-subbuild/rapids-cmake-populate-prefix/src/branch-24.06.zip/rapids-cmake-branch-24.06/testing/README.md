
# RAPIDS CMake Testing

## Synopsis

This is a collection of CMake tests to verify that rapids-cmake works as
expected.

## Requirements

- CUDA compiler
- PNG Library ( for find_package tests )
- ZLIB Library ( for find_package tests )
