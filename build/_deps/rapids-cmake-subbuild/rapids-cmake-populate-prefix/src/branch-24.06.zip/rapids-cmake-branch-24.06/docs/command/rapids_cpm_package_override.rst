.. cmake-module:: ../../rapids-cmake/cpm/package_override.cmake
