.. cmake-module:: ../../rapids-cmake/cpm/generate_pinned_versions.cmake
