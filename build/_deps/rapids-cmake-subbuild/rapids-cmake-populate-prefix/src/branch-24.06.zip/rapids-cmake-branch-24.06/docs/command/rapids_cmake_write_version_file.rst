.. cmake-module:: ../../rapids-cmake/cmake/write_version_file.cmake
