.. cmake-module:: ../../rapids-cmake/cuda/init_architectures.cmake
