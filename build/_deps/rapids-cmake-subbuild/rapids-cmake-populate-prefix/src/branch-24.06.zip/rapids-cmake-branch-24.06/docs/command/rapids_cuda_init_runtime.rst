.. cmake-module:: ../../rapids-cmake/cuda/init_runtime.cmake
