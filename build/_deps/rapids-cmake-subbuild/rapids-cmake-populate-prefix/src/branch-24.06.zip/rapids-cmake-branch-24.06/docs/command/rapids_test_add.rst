.. cmake-module:: ../../rapids-cmake/test/add.cmake
