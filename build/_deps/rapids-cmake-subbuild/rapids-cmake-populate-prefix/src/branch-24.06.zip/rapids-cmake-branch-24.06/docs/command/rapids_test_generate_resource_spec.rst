.. cmake-module:: ../../rapids-cmake/test/generate_resource_spec.cmake
