.. cmake-module:: ../../rapids-cmake/cmake/write_git_revision_file.cmake
