.. cmake-module:: ../../rapids-cmake/cpm/nvbench.cmake
